<?php
namespace Jaspel\Auth;

class Exception extends \Exception
{
}
