<?php
namespace Jaspel\Mail;

class Exception extends \Exception
{
}
