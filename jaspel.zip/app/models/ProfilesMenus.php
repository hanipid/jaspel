<?php
namespace Jaspel\Models;

use Phalcon\Mvc\Model;

/**
 * Relation between Profiles and Menus
 */
class ProfilesMenus extends Model
{
	
}