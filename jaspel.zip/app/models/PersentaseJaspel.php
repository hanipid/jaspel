<?php
namespace Jaspel\Models;

use Phalcon\Mvc\Model;

/**
 * Persentase Jaspel
 */
class PersentaseJaspel extends Model
{
	
}