<?php
namespace Jaspel\Models;

use Phalcon\Mvc\Model;

/**
 * Pendapatan Tambahan
 */
class PendapatanTambahan extends Model
{
	
	
}