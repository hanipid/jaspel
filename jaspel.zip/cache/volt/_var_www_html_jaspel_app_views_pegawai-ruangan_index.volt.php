<?= $this->tag->stylesheetLink('vendor/almasaeed2010/adminlte/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css') ?>
<?= $this->tag->javascriptInclude('vendor/almasaeed2010/adminlte/bower_components/datatables.net/js/jquery.dataTables.min.js') ?>
<?= $this->tag->javascriptInclude('vendor/almasaeed2010/adminlte/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js') ?>

<?= $this->getContent() ?>

<?php if ($this->auth->getIdentity()['profile'] == 'Kepegawaian' || $this->auth->getIdentity()['profile'] == 'Super User') { ?>
<div class="col-md-12">
  <div class="box box-primary">
    <div class="box-body text-center">
      <form method="get" action="" class="form-inline">
        <select id="ruangan" name="ruangan" class="form-control">
          <option value="0">-- Semua Ruangan ---</option>
          <?php foreach ($ruangan as $r) { ?>
          <option value="<?= $r->id ?>"><?= $r->namaRuang ?></option>
          <?php } ?>
        </select>
        <input type="submit" name="submit" value="Submit" class="btn btn-default">
      </form>
    </div>
  </div>
</div>
<?php } ?>

<div class="col-md-12">
  <div class="box box-primary">
    <div class="box-header with-border">
      <h3 class="box-title">Pegawai Ruangan <?= $this->auth->getIdentity()['profile'] ?></h3>
      <div class="box-tools pull-right">
        
        <?php if ($idRuangan != 0 && $this->auth->getIdentity()['profile'] != 'Super User') { ?>
          <?= $this->tag->linkTo(['pegawai-ruangan/create/' . $idRuangan, '<i class=\'glyphicon glyphicon-plus\'></i> Tambah Data', 'class' => 'btn btn-primary']) ?>
        <?php } ?>
      </div>
    </div>
    <!-- /.box-header -->

    <div class="box-body">
      
      <table id="dataTable" class="table table-bordered table-striped" align="center">
        <thead>
          <tr>
            <th width="4%" class="text-center">#</th>
            <th>Nama</th>
            <th>Ruangan</th>
            
            <th></th>
          </tr>
        </thead>
        <tbody>
          
          <?php $v127489343461810716641iterator = $pegawaiRuangan; $v127489343461810716641incr = 0; $v127489343461810716641loop = new stdClass(); $v127489343461810716641loop->self = &$v127489343461810716641loop; $v127489343461810716641loop->length = count($v127489343461810716641iterator); $v127489343461810716641loop->index = 1; $v127489343461810716641loop->index0 = 1; $v127489343461810716641loop->revindex = $v127489343461810716641loop->length; $v127489343461810716641loop->revindex0 = $v127489343461810716641loop->length - 1; ?><?php foreach ($v127489343461810716641iterator as $pr) { ?><?php $v127489343461810716641loop->first = ($v127489343461810716641incr == 0); $v127489343461810716641loop->index = $v127489343461810716641incr + 1; $v127489343461810716641loop->index0 = $v127489343461810716641incr; $v127489343461810716641loop->revindex = $v127489343461810716641loop->length - $v127489343461810716641incr; $v127489343461810716641loop->revindex0 = $v127489343461810716641loop->length - ($v127489343461810716641incr + 1); $v127489343461810716641loop->last = ($v127489343461810716641incr == ($v127489343461810716641loop->length - 1)); ?>
          <tr>
            <td class="text-center"><?= $v127489343461810716641loop->index ?></td>
            <td><?= $pr->pegawai->gelarDepan ?> <?= ucwords($pr->pegawai->namaPegawai) ?> <?= $pr->pegawai->gelarBelakang ?></td>
            <td><?php if (isset($pr->ruangan->namaRuang)) { ?> <?= ucwords($pr->ruangan->namaRuang) ?> <?php } ?></td>
            
            
            <td width="2%">
              <?php if (isset($pr->ruangan->jenisRuang)) { ?>
                <?php $is_kantor = $pr->ruangan->jenisRuang; ?>
              <?php } else { ?>
                <?php $is_kantor = 0; ?>
              <?php } ?>
              <?php if (($this->auth->getIdentity()['profile'] == 'Kepegawaian' && ($is_kantor == 'kantor' || $pr->pegawai->posisiStatus == 'bukandokter')) || ($this->auth->getIdentity()['profile'] == 'Pelayanan')) { ?>
                <?= $this->tag->linkTo(['pegawai-ruangan/delete/' . $pr->id . '/' . $idRuangan, '<i class="glyphicon glyphicon-remove"></i> Non Aktif', 'class' => 'btn btn-danger btn-sm', 'onclick' => 'return confirm(\'Are you sure?\')']) ?>
              <?php } ?>
            </td>
          </tr>
          <?php $v127489343461810716641incr++; } ?>
      
        </tbody>
      </table>

    </div>
    <!-- /.box-body -->

  </div>
  <!-- /.box -->
</div>
<!-- /.col-md-12 -->


<script>
$(document).ready(function() {
  $('#dataTable').dataTable();
});
</script>