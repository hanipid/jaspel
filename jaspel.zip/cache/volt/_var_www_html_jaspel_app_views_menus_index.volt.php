<?= $this->getContent() ?>

<div id="menus">

  <div class="loading text-center">Loading</div>

  <div class="box box-primary">
    <div class="box-header with-border">
      <h3 class="box-title">Menus</h3>
      <div class="box-tools pull-right">
        <?= $this->tag->linkTo(['menus/create', '<i class=\'icon-plus-sign\'></i> Create a menu', 'class' => 'btn btn-primary']) ?>
      </div>
    </div>
    <!-- /.box-header -->
    <!-- form start -->
    <form role="form">
      <div class="box-body"><?php $this->_macros['print_menu_level'] = function($__p = null) { if (isset($__p[0])) { $menu_level_items = $__p[0]; } else { if (isset($__p["menu_level_items"])) { $menu_level_items = $__p["menu_level_items"]; } else {  throw new \Phalcon\Mvc\View\Exception("Macro 'print_menu_level' was called without parameter: menu_level_items");  } }  ?><?php $v105604127518229872971iterator = $menu_level_items; $v105604127518229872971incr = 0; $v105604127518229872971loop = new stdClass(); $v105604127518229872971loop->self = &$v105604127518229872971loop; $v105604127518229872971loop->length = count($v105604127518229872971iterator); $v105604127518229872971loop->index = 1; $v105604127518229872971loop->index0 = 1; $v105604127518229872971loop->revindex = $v105604127518229872971loop->length; $v105604127518229872971loop->revindex0 = $v105604127518229872971loop->length - 1; ?><?php foreach ($v105604127518229872971iterator as $menu_item) { ?><?php $v105604127518229872971loop->first = ($v105604127518229872971incr == 0); $v105604127518229872971loop->index = $v105604127518229872971incr + 1; $v105604127518229872971loop->index0 = $v105604127518229872971incr; $v105604127518229872971loop->revindex = $v105604127518229872971loop->length - $v105604127518229872971incr; $v105604127518229872971loop->revindex0 = $v105604127518229872971loop->length - ($v105604127518229872971incr + 1); $v105604127518229872971loop->last = ($v105604127518229872971incr == ($v105604127518229872971loop->length - 1)); ?>

            <?php $next_menu_level_items = $menu_item->getChilds(); ?>
            <?php $isParents = $menu_item->isParents(); ?>
            <?php if ($v105604127518229872971loop->first) { ?>
              <?php if ($menu_item->parent == 0) { ?>
                <ol class="nav_menu_list">
              <?php } else { ?>
                <ol>
              <?php } ?>
            <?php } ?>

            <li data-id="<?= $menu_item->id ?>">


              <div class="row">
                <div class="col-md-8">
                  <?php if ($menu_item->parent == 0) { ?>
                    <i class="fa fa-arrows"></i>
                  <?php } ?>
                  <strong><?= $menu_item->nama ?></strong> <small><i><?= $menu_item->controller ?></i></small>
                </div>

                <div class="col-md-4">
                  <?php if (!$next_menu_level_items) { ?>
                    <a href="<?= $this->url->get('menus/delete/' . $menu_item->id) ?>" onclick="return confirm('Are you sure?')" class="btn btn-danger cek" id="<?= $menu_item->id ?>" cek="0">Delete</a>
                  <?php } ?>
                  <a href="<?= $this->url->get('menus/edit/' . $menu_item->id) ?>" class="btn btn-warning">Edit</a>
                </div>
              </div>

              <?php if ($next_menu_level_items) { ?>
                  <?= $this->callMacro('print_menu_level', [$next_menu_level_items]) ?>
              <?php } ?>

            </li>

            <?php if ($v105604127518229872971loop->last) { ?>
              </ol>
            <?php } ?><?php $v105604127518229872971incr++; } ?><?php }; $this->_macros['print_menu_level'] = \Closure::bind($this->_macros['print_menu_level'], $this); ?>

        <?= $this->callMacro('print_menu_level', [$root_menu_items]) ?>
      </div>
      <!-- /.box-body -->

      <div class="box-footer">
        <?= $this->tag->linkTo(['menus', 'Refresh', 'class' => 'btn btn-primary']) ?>
      </div>
    </form>
  </div>
  <!-- /.box -->
</div>

<?= $this->tag->javascriptInclude('js/jquery-sortable.js') ?>
<script>
/**
* JQUERY SORTABLE
**/
$(function  () {
  $('.loading').hide();
  // nav_menu_list
  var group = $("ol.nav_menu_list").sortable({
    group: 'nav_menu_list',
    delay: 500,
    onDrop: function ($item, container, _super) {
      var data = group.sortable("serialize").get();
      var sorted = [];

      $('.nav_menu_list li').each(function(){
        sorted.push($(this).data('id'));
      });

      var jsonString = JSON.stringify(sorted, null, ' ');
      // alert(jsonString);

      $.ajax({
        data: {id:sorted},
        type: 'POST',
        url: "<?= $this->url->get('menus/order') ?>",
        success : function(response){
          console.log("saved");
          $('.loading').show();
          // $("#menus").html(response);
          $('.loading').hide();
        },
        fail : function(){
          alert("Gagal");
        }
      });
      _super($item, container);
    }
  });
});
</script>