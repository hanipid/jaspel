
<!--
BODY TAG OPTIONS:
=================
Apply one or more of the following classes to get the
desired effect
|---------------------------------------------------------|
| SKINS         | skin-blue                               |
|               | skin-black                              |
|               | skin-purple                             |
|               | skin-yellow                             |
|               | skin-red                                |
|               | skin-green                              |
|---------------------------------------------------------|
|LAYOUT OPTIONS | fixed                                   |
|               | layout-boxed                            |
|               | layout-top-nav                          |
|               | sidebar-collapse                        |
|               | sidebar-mini                            |
|---------------------------------------------------------|
-->

<body class="hold-transition skin-blue fixed">
  <div class="wrapper">

    <header class="main-header">

      <!-- Logo -->
      <a href="index2.html" class="logo">
        <!-- mini logo for sidebar mini 50x50 pixels -->
        <span class="logo-mini"><b>J</b>P</span>
        <!-- logo for regular state and mobile devices -->
        <span class="logo-lg"><b>JAS</b>PEL</span>
      </a>

      <nav class="navbar navbar-static-top">
        <!-- Sidebar toggle button-->
        <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
          <span class="sr-only">Toggle navigation</span>
        </a>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="navbar-collapse">
          
          
          <ul class="nav navbar-nav navbar-right" style="margin-right:0px;">
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown"><?= $this->auth->getName() ?> <b class="caret"></b></a>
              <ul class="dropdown-menu">
                <li><?= $this->tag->linkTo(['users/changePassword', 'Change Password']) ?></li>
              </ul>
            </li>
            <li><?= $this->tag->linkTo(['session/logout', 'Logout']) ?></li>
          </ul>
        </div>
        <!-- /.navbar-collapse -->

      </nav>
    </header>

    <aside class="main-sidebar">
      <!-- Inner sidebar -->
      <section class="sidebar">
        <!-- Sidebar Menu -->
        <ul class="sidebar-menu" data-widget="tree" data-animation-speed="200"><?php $this->_macros['print_menu_level'] = function($__p = null) { if (isset($__p[0])) { $menu_level_items = $__p[0]; } else { if (isset($__p["menu_level_items"])) { $menu_level_items = $__p["menu_level_items"]; } else {  throw new \Phalcon\Mvc\View\Exception("Macro 'print_menu_level' was called without parameter: menu_level_items");  } } if (isset($__p[1])) { $checkper = $__p[1]; } else { if (isset($__p["checkper"])) { $checkper = $__p["checkper"]; } else {  throw new \Phalcon\Mvc\View\Exception("Macro 'print_menu_level' was called without parameter: checkper");  } }  ?><?php $v127489343461810716641iterator = $menu_level_items; $v127489343461810716641incr = 0; $v127489343461810716641loop = new stdClass(); $v127489343461810716641loop->self = &$v127489343461810716641loop; $v127489343461810716641loop->length = count($v127489343461810716641iterator); $v127489343461810716641loop->index = 1; $v127489343461810716641loop->index0 = 1; $v127489343461810716641loop->revindex = $v127489343461810716641loop->length; $v127489343461810716641loop->revindex0 = $v127489343461810716641loop->length - 1; ?><?php foreach ($v127489343461810716641iterator as $menu_item) { ?><?php $v127489343461810716641loop->first = ($v127489343461810716641incr == 0); $v127489343461810716641loop->index = $v127489343461810716641incr + 1; $v127489343461810716641loop->index0 = $v127489343461810716641incr; $v127489343461810716641loop->revindex = $v127489343461810716641loop->length - $v127489343461810716641incr; $v127489343461810716641loop->revindex0 = $v127489343461810716641loop->length - ($v127489343461810716641incr + 1); $v127489343461810716641loop->last = ($v127489343461810716641incr == ($v127489343461810716641loop->length - 1)); ?>
              <?php $is_parents = $menu_item->isParents(); ?>

              
              <?php $is_ok = false; ?>
              <?php foreach ($checkper as $cp) { ?>
                <?php if ($menu_item->controller == $cp->resource || $menu_item->url == '#') { ?>
                  <?php $is_ok = true; ?>
                <?php } ?>
              <?php } ?>


              
              <?php $is_ok2 = false; ?>
              <?php if (is_array($menu_item->getChilds()) || is_object($menu_item->getChilds())) { ?>
              <?php foreach ($menu_item->getChilds() as $child) { ?>
                
                <?php foreach ($checkper as $cp) { ?>
                  
                  <?php if ($child->controller == $cp->resource) { ?>
                    <?php $is_ok2 = true; ?>
                  <?php } ?>
                <?php } ?> 
              <?php } ?> 
              <?php } ?>



              
              <?php if ($is_ok) { ?>
                
                <?php if ($menu_item->controller == $this->dispatcher->getControllerName()) { ?>
                  <li class="active">
                    <a href="<?= $this->url->get($menu_item->url) ?>"><i class="fa fa-circle"></i> <?= $menu_item->nama ?></a>
                <?php } elseif ($is_parents == true) { ?>
                  
                  <?php if ($is_ok2) { ?>
                    <?php if ($this->dispatcher->getControllerName() == $menu_item->isThis($menu_item->id, $this->dispatcher->getControllerName())) { ?>
                      <li class="treeview active">
                        <a href="<?= $this->url->get($menu_item->url) ?>"><i class="fa fa-circle"></i> <?= $menu_item->nama ?> <i class="fa fa-angle-left pull-right"></i></a>
                        <ul class="treeview-menu" style="display: block">
                    <?php } else { ?>
                      <li class="treeview">
                        <a href="<?= $this->url->get($menu_item->url) ?>"><i class="fa fa-circle-o"></i> <?= $menu_item->nama ?> <i class="fa fa-angle-left pull-right"></i></a>
                        <ul class="treeview-menu">
                    <?php } ?>
                    
                    <?php $next_menu_level_items = $menu_item->getChilds(); ?>
                    <?php $next_checkper = $menu_item->getCheckPermissions($this->auth->getIdentity()['profilesId']); ?>
                    <?php if ($next_menu_level_items) { ?>
                      <?= $this->callMacro('print_menu_level', [$next_menu_level_items, $next_checkper]) ?><?php } ?>
                    </ul> <!-- /.treeview-menu -->
                  <?php } ?>


                <?php } else { ?>
                  <li>
                    <a href="<?= $this->url->get($menu_item->url) ?>"><i class="fa fa-circle-o"></i> <?= $menu_item->nama ?></a>
                <?php } ?>

                </li>
              <?php } ?><?php $v127489343461810716641incr++; } ?><?php }; $this->_macros['print_menu_level'] = \Closure::bind($this->_macros['print_menu_level'], $this); ?>

          <?= $this->callMacro('print_menu_level', [$navMenu, $checkPermissions]) ?>
        </ul><!-- /.sidebar-menu -->

      </section><!-- /.sidebar -->
    </aside><!-- /.main-sidebar -->

    <div class="content-wrapper">
      

      <!-- Main content -->
      <section class="content container-fluid">
        <p><?php $this->flashSession->output() ?></p>
        <?= $this->getContent() ?>
      </section>
    </div>
    <!-- /.content-wrapper -->

    <!-- Main Footer -->
    <footer class="main-footer">
      <!-- To the right -->
      <div class="pull-right hidden-xs">
        Anything you want
      </div>
      <!-- Default to the left -->
      <div align="left">
        <strong>Copyright &copy; 2018 <a href="#">JagatCode</a>.</strong> All rights reserved.
      </div>
    </footer>

  </div>
  <!-- /.wrapper -->
</body>