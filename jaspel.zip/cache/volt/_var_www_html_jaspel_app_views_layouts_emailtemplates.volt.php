<html>
<head></head>
<body style="background-color: #E4E4E4;padding: 20px; margin: 0; min-width: 640px;">
	<table border="0" cellspacing="0" width="530" style="color:#262626;background-color:#fff;
		padding:27px 30px 20px 30px;margin:auto; border:1px solid #e1e1e1;">
		<tbody>
			<!-- header -->
			<tr style="background:#D44413">
				<td style="padding-left:20px">
					<a target="_blank" style="text-decoration:none;color:inherit;font-family:'HelveticaNeue','Helvetica Neue',Helvetica,Arial,sans-serif;font-weight:normal;">
						<h1 style="color:#fff">Vökuró</h1>
					</a>
				</td>
			</tr>
		</tbody>

		<?= $this->getContent() ?>

		<!--footer-->
		<tbody>
			<tr>
				<td align="right" style="padding:25px 0  0 0;">
					<table border="0" cellspacing="0" cellpadding="0" style="padding-bottom:9px;" align="right">
						<tbody>
							<tr style="border-bottom:1px solid #999999;">
								<td width="24" style="padding:0 7px 0 0;">
									<a href="http://www.facebook.com/pages/Phalcon/134230726685897" style="border-width:0;">
										<img src="http://<?= $publicUrl ?>/img/facebook.gif" width="24" height="24" alt="Facebook Image">
									</a>
								</td>
								<td width="24">
									<a href="http://twitter.com/phalconphp" style="border-width:0;">
										<img src="http://<?= $publicUrl ?>/img/twitter.gif" width="24" height="24" alt="Twitter Image">
									</a>
								</td>
							</tr>
							<tr style="height:1px; background:#000;padding-top:15px">
								<td></td>
								<td></td>
								<td></td>
							</tr>
						</tbody>
					</table>
				</td>
			</tr>
		</tbody>
	</table>

	</body>
</html>