<?= $this->getContent() ?>



<div class="col-md-12">
  <div class="box box-primary">
    <div class="box-header with-border">
      <h3 class="box-title">Pengaturan Persentase First Direksi</h3>
      <div class="box-tools pull-right">
        <?= $this->tag->linkTo(['setjas-persentase-direksi/create/1', '<i class=\'glyphicon glyphicon-plus\'></i> Tambah Data', 'class' => 'btn btn-primary']) ?>
      </div>
    </div>
    <!-- /.box-header -->

    <div class="box-body">
      
      <table class="table table-bordered table-striped" align="center">
        <thead>
          <tr>
            <th width="4%" class="text-center">#</th>
            <th>Nama</th>
            <th width="10%">Persentase</th>
          </tr>
        </thead>
        <tbody>
          
          <?php $persentase1 = 0; ?>
          <?php $v97226849699986250901iterator = $firstDireksi; $v97226849699986250901incr = 0; $v97226849699986250901loop = new stdClass(); $v97226849699986250901loop->self = &$v97226849699986250901loop; $v97226849699986250901loop->length = count($v97226849699986250901iterator); $v97226849699986250901loop->index = 1; $v97226849699986250901loop->index0 = 1; $v97226849699986250901loop->revindex = $v97226849699986250901loop->length; $v97226849699986250901loop->revindex0 = $v97226849699986250901loop->length - 1; ?><?php foreach ($v97226849699986250901iterator as $d1) { ?><?php $v97226849699986250901loop->first = ($v97226849699986250901incr == 0); $v97226849699986250901loop->index = $v97226849699986250901incr + 1; $v97226849699986250901loop->index0 = $v97226849699986250901incr; $v97226849699986250901loop->revindex = $v97226849699986250901loop->length - $v97226849699986250901incr; $v97226849699986250901loop->revindex0 = $v97226849699986250901loop->length - ($v97226849699986250901incr + 1); $v97226849699986250901loop->last = ($v97226849699986250901incr == ($v97226849699986250901loop->length - 1)); ?>
          <tr>
            <td class="text-center"><?= $v97226849699986250901loop->index ?></td>
            <td><?= ucwords($d1->pegawai->namaPegawai) ?></td>
            <td><?= $d1->nilaiPersentase ?>%</td>
            <td width="2%"><?= $this->tag->linkTo(['setjas-persentase-direksi/edit/' . $d1->id, '<i class="glyphicon glyphicon-pencil"></i> Edit', 'class' => 'btn btn-primary']) ?></td>
            <td width="2%"><?= $this->tag->linkTo(['setjas-persentase-direksi/delete/' . $d1->id, '<i class="glyphicon glyphicon-remove"></i> Non Aktif', 'class' => 'btn btn-danger', 'onclick' => 'return confirm(\'Are you sure?\')']) ?></td>
          </tr>
          <?php $persentase1 += $d1->nilaiPersentase; ?>
          <?php $v97226849699986250901incr++; } ?>
      
        </tbody>
        <tfoot>
          <tr>
            <th colspan="2">Total</th>
            <th><?= $persentase1 ?>%</th>
          </tr>
        </tfoot>
      </table>

    </div>
    <!-- /.box-body -->

  </div>
  <!-- /.box -->
</div>
<!-- /.col-md-12 -->

<div class="col-md-12">
  <div class="box box-primary">
    <div class="box-header with-border">
      <h3 class="box-title">Pengaturan Persentase Second Direksi</h3>
      <div class="box-tools pull-right">
        <?= $this->tag->linkTo(['setjas-persentase-direksi/create/2', '<i class=\'glyphicon glyphicon-plus\'></i> Tambah Data', 'class' => 'btn btn-primary']) ?>
      </div>
    </div>
    <!-- /.box-header -->

    <div class="box-body">
      <table class="table table-bordered table-striped" align="center">
        <thead>
          <tr>
            <th width="4%" class="text-center">#</th>
            <th>Nama</th>
            <th width="10%">Persentase</th>
          </tr>
        </thead>
        <tbody>
          
          <?php $persentase2 = 0; ?>
          <?php $v97226849699986250901iterator = $secondDireksi; $v97226849699986250901incr = 0; $v97226849699986250901loop = new stdClass(); $v97226849699986250901loop->self = &$v97226849699986250901loop; $v97226849699986250901loop->length = count($v97226849699986250901iterator); $v97226849699986250901loop->index = 1; $v97226849699986250901loop->index0 = 1; $v97226849699986250901loop->revindex = $v97226849699986250901loop->length; $v97226849699986250901loop->revindex0 = $v97226849699986250901loop->length - 1; ?><?php foreach ($v97226849699986250901iterator as $d2) { ?><?php $v97226849699986250901loop->first = ($v97226849699986250901incr == 0); $v97226849699986250901loop->index = $v97226849699986250901incr + 1; $v97226849699986250901loop->index0 = $v97226849699986250901incr; $v97226849699986250901loop->revindex = $v97226849699986250901loop->length - $v97226849699986250901incr; $v97226849699986250901loop->revindex0 = $v97226849699986250901loop->length - ($v97226849699986250901incr + 1); $v97226849699986250901loop->last = ($v97226849699986250901incr == ($v97226849699986250901loop->length - 1)); ?>
          <tr>
            <td class="text-center"><?= $v97226849699986250901loop->index ?></td>
            <td><?= ucwords($d2->pegawai->namaPegawai) ?></td>
            <td><?= $d2->nilaiPersentase ?>%</td>
            <td width="2%"><?= $this->tag->linkTo(['setjas-persentase-direksi/edit/' . $d2->id, '<i class="glyphicon glyphicon-pencil"></i> Edit', 'class' => 'btn btn-primary']) ?></td>
            <td width="2%"><?= $this->tag->linkTo(['setjas-persentase-direksi/delete/' . $d2->id, '<i class="glyphicon glyphicon-remove"></i> Non Aktif', 'class' => 'btn btn-danger', 'onclick' => 'return confirm(\'Are you sure?\')']) ?></td>
          </tr>
          <?php $persentase2 += $d2->nilaiPersentase; ?>
          <?php $v97226849699986250901incr++; } ?>
      
        </tbody>
        <tfoot>
          <tr>
            <th colspan="2">Total</th>
            <th><?= $persentase2 ?>%</th>
          </tr>
        </tfoot>
      </table>

    </div>
    <!-- /.box-body -->

  </div>
  <!-- /.box -->
</div>
<!-- /.col-md-12 -->