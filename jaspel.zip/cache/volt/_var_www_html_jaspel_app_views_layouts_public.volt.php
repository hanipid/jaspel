<body class="skin-blue layout-top-nav">

  <header class="main-header">
    <nav class="navbar navbar-static-top">
      <div class="container-fluid">
        <div class="navbar-header">
          <?= $this->tag->linkTo([null, 'class' => 'navbar-brand', 'JASPEL']) ?>
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse">
            <i class="fa fa-bars"></i>
          </button>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="navbar-collapse">
          <ul class="nav navbar-nav"><?php $menus = ['Home' => 'index', 'About' => 'about']; ?><?php foreach ($menus as $key => $value) { ?>
              <?php if ($value == $this->dispatcher->getControllerName()) { ?>
              <li class="active"><?= $this->tag->linkTo([$value, $key]) ?></li>
              <?php } else { ?>
              <li><?= $this->tag->linkTo([$value, $key]) ?></li>
              <?php } ?><?php } ?></ul>
          
          <ul class="nav navbar-nav navbar-right"><?php if (isset($logged_in) && !(empty($logged_in))) { ?><li><?= $this->tag->linkTo(['users', 'Users Panel']) ?></li>
            <li><?= $this->tag->linkTo(['session/logout', 'Logout']) ?></li>
            <?php } else { ?>
            <li><?= $this->tag->linkTo(['session/login', 'Login']) ?></li>
            <?php } ?>
          </ul>
        </div>
        <!-- /.navbar-collapse -->
      </div>
      <!-- /.container-fluid -->
    </nav>
  </header>

  <div class="container main-container">
    <?= $this->getContent() ?>
  </div>

  <footer>
  
  </footer>


</body>