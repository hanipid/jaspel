<?= $this->getContent() ?>

<div class="col-md-12">
  <div class="box box-primary">
    <div class="box-header with-border">
      <h3 class="box-title">Pelayanan Instalasi</h3>
      <div class="box-tools pull-right">
      </div>
    </div>
    <!-- /.box-header -->

    <div class="box-body">

      <table class="table table-hover table-striped">
        <thead>
          <tr>
            <th></th>
            
            <th></th>
            <th></th>
          </tr>
        </thead>
        <tbody>
      
          <tr>
            <td>Karcis</td>
            
            <td width="2%"><?= $this->tag->linkTo(['setins-pelayanan/edit/' . $profile->id, '<i class="glyphicon glyphicon-pencil"></i> Detail', 'class' => 'btn btn-primary']) ?></td>
            <td width="2%"><?= $this->tag->linkTo(['setins-pelayanan/delete/' . $profile->id, '<i class="glyphicon glyphicon-remove"></i> Delete', 'class' => 'btn btn-danger', 'onclick' => 'return confirm(\'Are you sure?\')']) ?></td>
          </tr>
      
          <tr>
            <td>Kamar</td>
            
            <td width="2%"><?= $this->tag->linkTo(['setins-pelayanan/edit/' . $profile->id, '<i class="glyphicon glyphicon-pencil"></i> Detail', 'class' => 'btn btn-primary']) ?></td>
            <td width="2%"><?= $this->tag->linkTo(['setins-pelayanan/delete/' . $profile->id, '<i class="glyphicon glyphicon-remove"></i> Delete', 'class' => 'btn btn-danger', 'onclick' => 'return confirm(\'Are you sure?\')']) ?></td>
          </tr>
      
          <tr>
            <td>Jasa Dokter</td>
            
            <td width="2%"><?= $this->tag->linkTo(['setins-pelayanan/edit/' . $profile->id, '<i class="glyphicon glyphicon-pencil"></i> Detail', 'class' => 'btn btn-primary']) ?></td>
            <td width="2%"><?= $this->tag->linkTo(['setins-pelayanan/delete/' . $profile->id, '<i class="glyphicon glyphicon-remove"></i> Delete', 'class' => 'btn btn-danger', 'onclick' => 'return confirm(\'Are you sure?\')']) ?></td>
          </tr>
      
          <tr>
            <td>Jasa Perawat</td>
            
            <td width="2%"><?= $this->tag->linkTo(['setins-pelayanan/edit/' . $profile->id, '<i class="glyphicon glyphicon-pencil"></i> Detail', 'class' => 'btn btn-primary']) ?></td>
            <td width="2%"><?= $this->tag->linkTo(['setins-pelayanan/delete/' . $profile->id, '<i class="glyphicon glyphicon-remove"></i> Delete', 'class' => 'btn btn-danger', 'onclick' => 'return confirm(\'Are you sure?\')']) ?></td>
          </tr>
      
          <tr>
            <td>Tindakan Dokter</td>
            
            <td width="2%"><?= $this->tag->linkTo(['setins-pelayanan/edit/' . $profile->id, '<i class="glyphicon glyphicon-pencil"></i> Detail', 'class' => 'btn btn-primary']) ?></td>
            <td width="2%"><?= $this->tag->linkTo(['setins-pelayanan/delete/' . $profile->id, '<i class="glyphicon glyphicon-remove"></i> Delete', 'class' => 'btn btn-danger', 'onclick' => 'return confirm(\'Are you sure?\')']) ?></td>
          </tr>
      
          <tr>
            <td>Tindakan Perawat</td>
            
            <td width="2%"><?= $this->tag->linkTo(['setins-pelayanan/edit/' . $profile->id, '<i class="glyphicon glyphicon-pencil"></i> Detail', 'class' => 'btn btn-primary']) ?></td>
            <td width="2%"><?= $this->tag->linkTo(['setins-pelayanan/delete/' . $profile->id, '<i class="glyphicon glyphicon-remove"></i> Delete', 'class' => 'btn btn-danger', 'onclick' => 'return confirm(\'Are you sure?\')']) ?></td>
          </tr>

        </tbody>
      </table>

    </div>
    <!-- /.box-body -->
  </div>
  <!-- /.box -->
</div>
<!-- /.col-md-12 -->