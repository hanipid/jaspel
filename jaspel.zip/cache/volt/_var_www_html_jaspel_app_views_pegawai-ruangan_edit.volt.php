<?= $this->getContent() ?>

<form method="post" action="">
  <div class="col-md-4 col-md-offset-4">
    <div class="box box-primary">
      <div class="box-header with-border">
        <h3 class="box-title"><?= ucwords($pegawaiRuangan->pegawai->namaPegawai) ?></h3>
        <div class="box-tools pull-right">
          <a href="<?= $this->url->get('pegawai-ruangan') ?>" class="btn btn-box-tool"><i class="fa fa-times"></i></a>
        </div>
      </div>
      <!-- /.box-header -->

      <div class="box-body">
        
        <div class="form-group">
          <label for="ruangan">Pilih ruangan</label>
          <?= $this->tag->select(['ruangan', $ruangan, 'using' => ['id', 'namaRuang'], 'class' => 'form-control', 'value' => $pegawaiRuangan->idRuangan]) ?>
        </div>

      </div>
      <!-- /.box-body -->

      <div class="box-footer">
        <?= $this->tag->submitButton(['Save', 'class' => 'btn btn-primary']) ?>
      </div>

    </div>
    <!-- /.box -->
  </div>
  <!-- /.col-md-12 -->
</form>