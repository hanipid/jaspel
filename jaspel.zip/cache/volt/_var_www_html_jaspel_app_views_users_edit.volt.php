
<form class="form" method="post" autocomplete="off">

  <?= $this->getContent() ?>

  <div class="box box-primary">
    <div class="box-header with-border">
      <h3 class="box-title">Edit users</h3>
      <div class="box-tools pull-right">

      </div>
    </div>
    <!-- /.box-header -->
    <div class="box-body">
      
      <ul class="nav nav-tabs">
        <li class="active"><a href="#A" data-toggle="tab">Basic</a></li>
        <li><a href="#B" data-toggle="tab">Successful Logins</a></li>
        <li><a href="#C" data-toggle="tab">Password Changes</a></li>
        <li><a href="#D" data-toggle="tab">Reset Passwords</a></li>
      </ul>

      <div class="tabbable">
        <div class="tab-content">
          <div class="tab-pane active" id="A">

            <?= $form->render('id') ?>

            <div class="col-md-4">

              <div class="form-group">
                <label for="name">Name</label>
                <?= $form->render('name') ?>
              </div>

              <div class="form-group">
                <label for="profilesId">Profile</label>
                <?= $form->render('profilesId') ?>
              </div>

              <div class="form-group" id="ruang">
                <label for="idRuangan">Ruangan</label>
                <?= $form->render('idRuangan') ?>
              </div>

              <div class="form-group">
                <label for="suspended">Suspended?</label>
                <?= $form->render('suspended') ?>
              </div>

            </div>

            <div class="col-md-4">

              <div class="form-group">
                <label for="email">E-Mail</label>
                <?= $form->render('email') ?>
              </div>

              <div class="form-group">
                <label for="banned">Banned?</label>
                <?= $form->render('banned') ?>
              </div>

              <div class="form-group">
                <label for="active">Confirmed?</label>
                <?= $form->render('active') ?>
              </div>

            </div>
          </div>

          <div class="tab-pane" id="B">
            <p>
              <table class="table table-bordered table-striped" align="center">
                <thead>
                  <tr>
                    <th>Id</th>
                    <th>IP Address</th>
                    <th>User Agent</th>
                  </tr>
                </thead>
                <tbody>
                <?php $v161797678288806524091iterated = false; ?><?php foreach ($user->successLogins as $login) { ?><?php $v161797678288806524091iterated = true; ?>
                  <tr>
                    <td><?= $login->id ?></td>
                    <td><?= $login->ipAddress ?></td>
                    <td><?= $login->userAgent ?></td>
                  </tr>
                <?php } if (!$v161797678288806524091iterated) { ?>
                  <tr><td colspan="3" align="center">User does not have successfull logins</td></tr>
                <?php } ?>
                </tbody>
              </table>
            </p>
          </div>

          <div class="tab-pane" id="C">
            <p>
              <table class="table table-bordered table-striped" align="center">
                <thead>
                  <tr>
                    <th>Id</th>
                    <th>IP Address</th>
                    <th>User Agent</th>
                    <th>Date</th>
                  </tr>
                </thead>
                <tbody>
                <?php $v161797678288806524091iterated = false; ?><?php foreach ($user->passwordChanges as $change) { ?><?php $v161797678288806524091iterated = true; ?>
                  <tr>
                    <td><?= $change->id ?></td>
                    <td><?= $change->ipAddress ?></td>
                    <td><?= $change->userAgent ?></td>
                    <td><?= date('Y-m-d H:i:s', $change->createdAt) ?></td>
                  </tr>
                <?php } if (!$v161797678288806524091iterated) { ?>
                  <tr><td colspan="4" align="center">User has not changed his/her password</td></tr>
                <?php } ?>
                </tbody>
              </table>
            </p>
          </div>

          <div class="tab-pane" id="D">
            <p>
              <table class="table table-bordered table-striped" align="center">
                <thead>
                  <tr>
                    <th>Id</th>
                    <th>Date</th>
                    <th>Reset?</th>
                  </tr>
                </thead>
                <tbody>
                <?php $v161797678288806524091iterated = false; ?><?php foreach ($user->resetPasswords as $reset) { ?><?php $v161797678288806524091iterated = true; ?>
                  <tr>
                    <th><?= $reset->id ?></th>
                    <th><?= date('Y-m-d H:i:s', $reset->createdAt) ?>
                    <th><?= ($reset->reset == 'Y' ? 'Yes' : 'No') ?>
                  </tr>
                <?php } if (!$v161797678288806524091iterated) { ?>
                  <tr><td colspan="3" align="center">User has not requested reset his/her password</td></tr>
                <?php } ?>
                </tbody>
              </table>
            </p>
          </div>

        </div>
      </div>

    </div>
    <!-- /.box-body -->

    <div class="box-footer">
      <button type="submit" class="btn btn-primary">Submit</button>
    </div>
  </div>
  <!-- /.box -->
</form>

<script>
if ($("#profilesId").val() != '4') {
  $("#ruang").hide();
}

$(function() {

  $("#profilesId").on("change", function(){
    if ($(this).val() == 4) {
      $("#ruang").show();
    } else {
      $("#ruang").hide();
    }
  })

});
</script>