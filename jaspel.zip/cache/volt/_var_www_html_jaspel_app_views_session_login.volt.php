<?= $this->getContent() ?>

<div class="login-box">
  <div class="login-logo">
    <a href="#"><strong>SIPJASPEL</strong></a>
    <p>RSUD MARDI WALUYO</p>
  </div>
  <!-- /.login-logo -->
  <div class="login-box-body">
    <p class="login-box-msg">Lengkapi form di bawah ini untuk mengakses JASPEL</p>

    <?= $this->tag->form([]) ?>
      <div class="form-group has-feedback">
				<?= $form->render('email') ?>
        <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
      </div>
      <div class="form-group has-feedback">
				<?= $form->render('password') ?>
        <span class="glyphicon glyphicon-lock form-control-feedback"></span>
      </div>
      <div class="row">
        
        <!-- /.col -->
        <div class="col-xs-4">
        	<?= $form->render('csrf', ['value' => $this->security->getToken()]) ?>
          <button type="submit" class="btn btn-primary btn-block btn-flat">Sign In</button>
        </div>
        <!-- /.col -->
      </div>
    </form>
    <hr>
    <a href="<?= $this->url->get('session/forgotPassword') ?>">Lupa password, klik di sini.</a><br>

  </div>
  <!-- /.login-box-body -->
</div>
<!-- /.login-box -->