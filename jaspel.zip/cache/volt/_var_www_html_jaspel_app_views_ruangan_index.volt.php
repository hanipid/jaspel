<?= $this->tag->stylesheetLink('vendor/almasaeed2010/adminlte/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css') ?>
<?= $this->tag->javascriptInclude('vendor/almasaeed2010/adminlte/bower_components/datatables.net/js/jquery.dataTables.min.js') ?>
<?= $this->tag->javascriptInclude('vendor/almasaeed2010/adminlte/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js') ?>

<?= $this->getContent() ?>

<div class="col-md-12">
  <div class="box box-primary">
    <div class="box-header with-border">
      <h3 class="box-title">Ruangan Aktif</h3>
      <div class="box-tools pull-right">
        <?= $this->tag->linkTo(['ruangan/create', '<i class=\'glyphicon glyphicon-plus\'></i> Tambah Ruangan', 'class' => 'btn btn-primary']) ?>
      </div>
    </div>
    <!-- /.box-header -->

    <div class="box-body">
      <table id="dataTable" class="table table-bordered table-striped" align="center">
        <thead>
          <tr>
            <th width="3%">No</th>
            <th>Nama Ruangan</th>
            <th>Jenis Ruangan</th>
            <th>Jumlah Pelayanan</th>
            <th></th>
            <th></th>
          </tr>
        </thead>
        <tbody>
      
          <?php $v152217799648640620531iterator = $ruanganJenisPelayanan; $v152217799648640620531incr = 0; $v152217799648640620531loop = new stdClass(); $v152217799648640620531loop->self = &$v152217799648640620531loop; $v152217799648640620531loop->length = count($v152217799648640620531iterator); $v152217799648640620531loop->index = 1; $v152217799648640620531loop->index0 = 1; $v152217799648640620531loop->revindex = $v152217799648640620531loop->length; $v152217799648640620531loop->revindex0 = $v152217799648640620531loop->length - 1; ?><?php foreach ($v152217799648640620531iterator as $rjp) { ?><?php $v152217799648640620531loop->first = ($v152217799648640620531incr == 0); $v152217799648640620531loop->index = $v152217799648640620531incr + 1; $v152217799648640620531loop->index0 = $v152217799648640620531incr; $v152217799648640620531loop->revindex = $v152217799648640620531loop->length - $v152217799648640620531incr; $v152217799648640620531loop->revindex0 = $v152217799648640620531loop->length - ($v152217799648640620531incr + 1); $v152217799648640620531loop->last = ($v152217799648640620531incr == ($v152217799648640620531loop->length - 1)); ?>
          <tr>
            <td><?= $v152217799648640620531loop->index ?></td>
            <td><?= ucwords($rjp->namaRuang) ?></td>
            <td><?= ucwords($rjp->jenisRuang) ?></td>
            <td><span class="btn btn-success"><?= $rjp->jumlahPelayanan ?></span></td>
            <td width="2%"><?= $this->tag->linkTo(['ruangan/edit/' . $rjp->id, '<i class="glyphicon glyphicon-pencil"></i> Detail', 'class' => 'btn btn-primary']) ?></td>
            <td width="2%"><?= $this->tag->linkTo(['ruangan/delete/' . $rjp->id, '<i class="glyphicon glyphicon-remove"></i> Delete', 'class' => 'btn btn-danger', 'onclick' => 'return confirm(\'Are you sure?\')']) ?></td>
          </tr>
          <?php $v152217799648640620531incr++; } ?>

        </tbody>
      </table>

    </div>
    <!-- /.box-body -->

  </div>
  <!-- /.box -->
</div>
<!-- /.col-md-12 -->

<script>
$(document).ready(function() {
    $('#dataTable').dataTable();
} );
</script>