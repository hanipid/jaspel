<?= $this->getContent() ?>





<div class="col-md-12">
  <div class="box box-primary">
    <div class="box-header with-border">
      <h3 class="box-title">Users</h3>
      <div class="box-tools pull-right">
        <form class="inline-form" method="post" action="<?= $this->url->get('users/search') ?>" autocomplete="off">
          <div class="input-group input-group-md">
            <?= $form->render('name') ?>
            <span class="input-group-btn">
              <button type="submit" class="btn btn-info btn-flat">Search!</button>
              <?= $this->tag->linkTo(['users/create', '<i class=\'glyphicon glyphicon-plus\'></i> Create Users', 'class' => 'btn btn-primary']) ?>
            </span>
          </div>
        </form>        
      </div>
    </div>
    <!-- /.box-header -->

    <div class="box-body">
      <?php $v174300871414187114991iterator = $page->items; $v174300871414187114991incr = 0; $v174300871414187114991loop = new stdClass(); $v174300871414187114991loop->self = &$v174300871414187114991loop; $v174300871414187114991loop->length = count($v174300871414187114991iterator); $v174300871414187114991loop->index = 1; $v174300871414187114991loop->index0 = 1; $v174300871414187114991loop->revindex = $v174300871414187114991loop->length; $v174300871414187114991loop->revindex0 = $v174300871414187114991loop->length - 1; ?><?php foreach ($v174300871414187114991iterator as $user) { ?><?php $v174300871414187114991loop->first = ($v174300871414187114991incr == 0); $v174300871414187114991loop->index = $v174300871414187114991incr + 1; $v174300871414187114991loop->index0 = $v174300871414187114991incr; $v174300871414187114991loop->revindex = $v174300871414187114991loop->length - $v174300871414187114991incr; $v174300871414187114991loop->revindex0 = $v174300871414187114991loop->length - ($v174300871414187114991incr + 1); $v174300871414187114991loop->last = ($v174300871414187114991incr == ($v174300871414187114991loop->length - 1)); ?>
      <?php if ($user) { ?>
        <?php if ($v174300871414187114991loop->first) { ?>
        <table class="table table-bordered table-striped" align="center">
          <thead>
            <tr>
              <th>Id</th>
              <th>Name</th>
              <th>Email</th>
              <th>Profile</th>
              <th>Banned?</th>
              <th>Suspended?</th>
              <th>Confirmed?</th>
            </tr>
          </thead>
          <tbody>
        <?php } ?>
            <tr>
              <td><?= $user->id ?></td>
              <td><?= $user->name ?></td>
              <td><?= $user->email ?></td>
              <td><?= $user->profile->name ?></td>
              <td><?= ($user->banned == 'Y' ? 'Yes' : 'No') ?></td>
              <td><?= ($user->suspended == 'Y' ? 'Yes' : 'No') ?></td>
              <td><?= ($user->active == 'Y' ? 'Yes' : 'No') ?></td>
              <td width="2%" class="text-center"><?= $this->tag->linkTo(['users/edit/' . $user->id, '<i class="glyphicon glyphicon-pencil"></i> Edit', 'class' => 'btn btn-primary']) ?></td>
              <td width="2%" class="text-center"><?= $this->tag->linkTo(['users/delete/' . $user->id, '<i class="glyphicon glyphicon-remove"></i> Delete', 'class' => 'btn btn-danger', 'onclick' => 'return confirm(\'Are you sure?\')']) ?></td>
            </tr>
        <?php if ($v174300871414187114991loop->last) { ?>
          </tbody>
          <tfoot>
            <tr>
              <td colspan="10" align="right">
                <ul class="pagination pagination-sm no-margin pull-right">
                  <li><?= $this->tag->linkTo(['users/search', '<i class="glyphicon glyphicon-fast-backward"></i> First']) ?></li>
                  <li><?= $this->tag->linkTo(['users/search?page=' . $page->before, '<i class="glyphicon glyphicon-step-backward"></i> Previous']) ?></li>
                  <li><?= $this->tag->linkTo(['users/search?page=' . $page->next, '<i class="glyphicon glyphicon-step-forward"></i> Next']) ?></li>
                  <li><?= $this->tag->linkTo(['users/search?page=' . $page->last, '<i class="glyphicon glyphicon-fast-forward"></i> Last']) ?></li>
                  <li><span class="help-inline"><?= $page->current ?>/<?= $page->total_pages ?></span></li>
                </ul>
              </td>
            </tr>
          </tfoot>
        </table>
        <?php } ?>
      <?php } else { ?>
        No users are recorded
      <?php } ?>
    <?php $v174300871414187114991incr++; } ?>
    </div>
    <!-- /.box-body -->

  </div>
  <!-- /.box -->
</div>
<!-- /.col-md-12 -->

<div class="col-md-12">
  <div class="box box-primary collapsed-box">
    <div class="box-header with-border">
      <h3 class="box-title">Advanced Search Users</h3>
      <div class="box-tools pull-right">
        <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-plus"></i></button>   
      </div>
    </div>
    <!-- /.box-header -->

    <div class="box-body">
      <form class="form" method="post" action="<?= $this->url->get('users/search') ?>" autocomplete="off">

        <div class="form-group">
          <label for="id">Id</label>
          <?= $form->render('id') ?>
        </div>

        <div class="form-group">
          <label for="name">Name</label>
          <?= $form->render('name') ?>
        </div>

        <div class="form-group">
          <label for="email">E-Mail</label>
          <?= $form->render('email') ?>
        </div>

        <div class="form-group">
          <label for="profilesId">Profile</label>
          <?= $form->render('profilesId') ?>
        </div>

        <div class="form-group">
          <button type="submit" class="btn btn-primary">Search</button>
        </div>

      </form>
    </div>
    <!-- /.box-body -->

  </div>
  <!-- /.box -->
</div>
<!-- /.col-md-12 -->