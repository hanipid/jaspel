<?= $this->getContent() ?>

<div class="col-md-12">
  <div class="box box-primary">
    <div class="box-header with-border">
      <h3 class="box-title">Profiles</h3>
      <div class="box-tools pull-right">
        <form class="inline-form" method="post" action="<?= $this->url->get('profiles/search') ?>" autocomplete="off">
          <div class="input-group input-group-md">
            <?= $form->render('name') ?>
            <span class="input-group-btn">
              <button type="submit" class="btn btn-info btn-flat">Search!</button>
              <?= $this->tag->linkTo(['profiles/create', '<i class=\'glyphicon glyphicon-plus\'></i> Create Profiles', 'class' => 'btn btn-primary']) ?>
            </span>
          </div>
        </form>        
      </div>
    </div>
    <!-- /.box-header -->

    <div class="box-body">
      <?php $v94841604907682722211iterator = $page->items; $v94841604907682722211incr = 0; $v94841604907682722211loop = new stdClass(); $v94841604907682722211loop->self = &$v94841604907682722211loop; $v94841604907682722211loop->length = count($v94841604907682722211iterator); $v94841604907682722211loop->index = 1; $v94841604907682722211loop->index0 = 1; $v94841604907682722211loop->revindex = $v94841604907682722211loop->length; $v94841604907682722211loop->revindex0 = $v94841604907682722211loop->length - 1; ?><?php foreach ($v94841604907682722211iterator as $profile) { ?><?php $v94841604907682722211loop->first = ($v94841604907682722211incr == 0); $v94841604907682722211loop->index = $v94841604907682722211incr + 1; $v94841604907682722211loop->index0 = $v94841604907682722211incr; $v94841604907682722211loop->revindex = $v94841604907682722211loop->length - $v94841604907682722211incr; $v94841604907682722211loop->revindex0 = $v94841604907682722211loop->length - ($v94841604907682722211incr + 1); $v94841604907682722211loop->last = ($v94841604907682722211incr == ($v94841604907682722211loop->length - 1)); ?>
        <?php if ($profile) { ?>
          <?php if ($v94841604907682722211loop->first) { ?>
          <table class="table table-bordered table-striped" align="center">
            <thead>
              <tr>
                <th>Id</th>
                <th>Name</th>
                <th>Active?</th>
              </tr>
            </thead>
            <tbody>
          <?php } ?>
              <tr>
                <td><?= $profile->id ?></td>
                <td><?= $profile->name ?></td>
                <td><?= ($profile->active == 'Y' ? 'Yes' : 'No') ?></td>
                <td width="2%"><?= $this->tag->linkTo(['profiles/edit/' . $profile->id, '<i class="glyphicon glyphicon-pencil"></i> Edit', 'class' => 'btn btn-primary']) ?></td>
                <td width="2%"><?= $this->tag->linkTo(['profiles/delete/' . $profile->id, '<i class="glyphicon glyphicon-remove"></i> Delete', 'class' => 'btn btn-danger', 'onclick' => 'return confirm(\'Are you sure?\')']) ?></td>
              </tr>
          <?php if ($v94841604907682722211loop->last) { ?>
            </tbody>
            <tfoot>
              <tr>
                <td colspan="10" align="right">
                  <ul class="pagination pagination-sm no-margin pull-right">
                    <li><?= $this->tag->linkTo(['profiles/search', '<i class="glyphicon glyphicon-fast-backward"></i> First']) ?></li>
                    <li><?= $this->tag->linkTo(['profiles/search?page=' . $page->before, '<i class="glyphicon glyphicon-step-backward"></i> Previous']) ?></li>
                    <li><?= $this->tag->linkTo(['profiles/search?page=' . $page->next, '<i class="glyphicon glyphicon-step-forward"></i> Next']) ?></li>
                    <li><?= $this->tag->linkTo(['profiles/search?page=' . $page->last, '<i class="glyphicon glyphicon-fast-forward"></i> Last']) ?></li>
                    <li><span class="help-inline"><?= $page->current ?>/<?= $page->total_pages ?></span></li>
                  </ul>
                </td>
              </tr>
            </tfoot>
          </table>
          <?php } ?>
        <?php } else { ?>
          No profiles are recorded
        <?php } ?>
      <?php $v94841604907682722211incr++; } ?>
    </div>
    <!-- /.box-body -->

  </div>
  <!-- /.box -->
</div>
<!-- /.col-md-12 -->