<form class="form" method="post" autocomplete="off">

	<?= $this->getContent() ?>

  <div class="col-md-6 col-md-offset-3">

    <div class="box box-primary">
      <div class="box-header with-border">
        <h3 class="box-title">Form Ubah Data Golongan Ruang</h3>
        <div class="box-tools pull-right">
          <a href="<?= $this->url->get('setpeg-data-GolonganRuang') ?>" class="btn btn-box-tool"><i class="fa fa-times"></i></a>
        </div>
      </div>
      <!-- /.box-header -->
      <div class="box-body">
        <div class="form-group">
          <label for="namaGolonganRuang">Nama Golongan Ruang</label>
          <?= $form->render('namaGolonganRuang') ?>
        </div>
      </div>
      <!-- /.box-body -->

      <div class="box-footer">
        <div class="form-group">
          <?= $this->tag->submitButton(['Update', 'class' => 'btn btn-primary']) ?>
        </div>
      </div>
    </div>
    <!-- /.box -->

  </div> <!-- /.col-md-6 -->

</form>