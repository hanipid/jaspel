<?= $this->getContent() ?>

<div class="col-md-12">
  <div class="box box-primary">
    <div class="box-header with-border">
      <h3 class="box-title">Detail Ruangan</h3>
      <div class="box-tools pull-right">
        <a href="<?= $this->url->get('ruangan') ?>" class="btn btn-box-tool"><i class="fa fa-times"></i></a>
      </div>
    </div>
    <!-- /.box-header -->

    <div class="box-body">
      
      <form method="post" class="form-inline">
        <div class="form-inline">
          <div class="form-group">
            <?= $form->render('namaRuang') ?>
          </div>
          <div class="form-group">
            <?= $form->render('jenisRuang') ?>
          </div>

          <div class="form-group">
            <?= $this->tag->submitButton(['Save', 'class' => 'btn btn-primary btn-lg']) ?>
          </div>

          <div class="form-group pull-right">
            <?php if ($ruangan->statusAktif == 1) { ?>
              <?= $this->tag->submitButton(['Aktif', 'class' => 'btn btn-success btn-lg', 'name' => 'statusAktif']) ?>
            <?php } else { ?>
              <?= $this->tag->submitButton(['Non Aktif', 'class' => 'btn btn-danger btn-lg', 'name' => 'statusAktif']) ?>
            <?php } ?>
          </div>
        </div>
      </form>

    </div>
    <!-- /.box-body -->

  </div>
  <!-- /.box -->
</div>
<!-- /.col-md-12 -->

<?php if ($ruangan->jenisRuang == 'pelayanan') { ?>
<div class="col-md-12">
  <div class="box box-primary">
    <div class="box-header with-border">
      <h3 class="box-title">Jenis Pelayanan</h3>
      <div class="box-tools pull-right">
        <?= $this->tag->linkTo(['ruangan/createPelayanan/' . $ruangan->id, '<i class=\'glyphicon glyphicon-plus\'></i> Tambah Pelayanan', 'class' => 'btn btn-primary']) ?>
      </div>
    </div>
    <!-- /.box-header -->

    <div class="box-body">
      
      <table class="table table-bordered table-striped" align="center">
        <thead>
          <tr>
            <th width="3%">No</th>
            <th>Jenis Pelayanan</th>
            <th>Sarana</th>
            <th>Pelayanan</th>
            <th></th>
            <th></th>
            <th></th>
          </tr>
        </thead>
        <tbody>
      
          <?php $v180693222858936457791iterator = $ruanganJenisPelayanan; $v180693222858936457791incr = 0; $v180693222858936457791loop = new stdClass(); $v180693222858936457791loop->self = &$v180693222858936457791loop; $v180693222858936457791loop->length = count($v180693222858936457791iterator); $v180693222858936457791loop->index = 1; $v180693222858936457791loop->index0 = 1; $v180693222858936457791loop->revindex = $v180693222858936457791loop->length; $v180693222858936457791loop->revindex0 = $v180693222858936457791loop->length - 1; ?><?php foreach ($v180693222858936457791iterator as $rjp) { ?><?php $v180693222858936457791loop->first = ($v180693222858936457791incr == 0); $v180693222858936457791loop->index = $v180693222858936457791incr + 1; $v180693222858936457791loop->index0 = $v180693222858936457791incr; $v180693222858936457791loop->revindex = $v180693222858936457791loop->length - $v180693222858936457791incr; $v180693222858936457791loop->revindex0 = $v180693222858936457791loop->length - ($v180693222858936457791incr + 1); $v180693222858936457791loop->last = ($v180693222858936457791incr == ($v180693222858936457791loop->length - 1)); ?>
          <tr>
            <td><?= $v180693222858936457791loop->index ?></td>
            <td><?= $rjp->jenisPelayanan->namaPelayanan ?></td>
            <td><?= $rjp->persentaseSarana ?></td>
            <td><?= $rjp->persentasePelayanan ?></td>
            <td width="2%"><?= $this->tag->linkTo(['ruangan/editPelayanan/' . $rjp->id, '<i class="glyphicon glyphicon-pencil"></i> Detail', 'class' => 'btn btn-primary']) ?></td>
            <td width="2%"><?= $this->tag->linkTo(['ruangan/deletePelayanan/' . $rjp->id, '<i class="glyphicon glyphicon-remove"></i> Delete', 'class' => 'btn btn-danger', 'onclick' => 'return confirm(\'Are you sure?\')']) ?></td>
          </tr>
          <?php $v180693222858936457791incr++; } ?>

        </tbody>
      </table>

    </div>
    <!-- /.box-body -->

    <div class="box-footer">
    </div>

  </div>
  <!-- /.box -->
</div>
<!-- /.col-md-12 -->
<?php } ?>

<?= $this->tag->linkTo(['ruangan/edit/#', 'Dokter 5', 'class' => 'btn btn-info btn-lg']) ?>
<?= $this->tag->linkTo(['ruangan/edit/#', 'Perawat / Non Perawat', 'class' => 'btn btn-info btn-lg']) ?>
<?= $this->tag->linkTo(['ruangan/edit/#', 'History Jaspel', 'class' => 'btn btn-info btn-lg']) ?>
