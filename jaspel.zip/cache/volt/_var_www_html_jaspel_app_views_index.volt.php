<!DOCTYPE html>
<html>
  <head>
    <title>Jasa Pelayanan RS. Mardi Waluyo</title>
    <?= $this->tag->stylesheetLink('css/fonts.css') ?>
    <?= $this->tag->stylesheetLink('vendor/almasaeed2010/adminlte/bower_components/jquery-ui/themes/smoothness/jquery-ui.min.css') ?>
    <?= $this->tag->stylesheetLink('vendor/almasaeed2010/adminlte/bower_components/bootstrap/dist/css/bootstrap.min.css') ?>
    <?= $this->tag->stylesheetLink('vendor/almasaeed2010/adminlte/bower_components/font-awesome/css/font-awesome.min.css') ?>
    <?= $this->tag->stylesheetLink('vendor/almasaeed2010/adminlte/bower_components/ionicons/css/ionicons.min.css') ?>
    <?= $this->tag->stylesheetLink('vendor/almasaeed2010/adminlte/dist/css/AdminLTE.min.css') ?>
    <?= $this->tag->stylesheetLink('vendor/almasaeed2010/adminlte/dist/css/skins/skin-blue.min.css') ?>
    <?= $this->tag->stylesheetLink('css/sorting.css') ?>
    <?= $this->tag->stylesheetLink('css/style.css') ?>

    <?= $this->tag->javascriptInclude('vendor/almasaeed2010/adminlte/bower_components/jquery/dist/jquery.min.js') ?>
    <?= $this->tag->javascriptInclude('vendor/almasaeed2010/adminlte/bower_components/jquery-ui/jquery-ui.min.js') ?>
    <?= $this->tag->javascriptInclude('vendor/almasaeed2010/adminlte/bower_components/bootstrap/dist/js/bootstrap.min.js') ?>
    <?= $this->tag->javascriptInclude('vendor/almasaeed2010/adminlte/bower_components/jquery-slimscroll/jquery.slimscroll.min.js') ?>
    <?= $this->tag->javascriptInclude('vendor/almasaeed2010/adminlte/dist/js/adminlte.min.js') ?>
  </head>

  <?= $this->getContent() ?>

</html>