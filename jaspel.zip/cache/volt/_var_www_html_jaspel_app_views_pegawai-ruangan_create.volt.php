<?= $this->tag->stylesheetLink('vendor/almasaeed2010/adminlte/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css') ?>
<?= $this->tag->javascriptInclude('vendor/almasaeed2010/adminlte/bower_components/datatables.net/js/jquery.dataTables.min.js') ?>
<?= $this->tag->javascriptInclude('vendor/almasaeed2010/adminlte/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js') ?>

<?= $this->getContent() ?>

<form id="listPegawai" method="post" action="">
  <div class="col-md-12">
    <div class="box box-primary">
      <div class="box-header with-border">
        <h3 class="box-title">List Pegawai</h3>
        <div class="box-tools pull-right">
          <a href="<?= $this->url->get('pegawai-ruangan') ?>" class="btn btn-box-tool"><i class="fa fa-times"></i></a>
        </div>
      </div>
      <!-- /.box-header -->

      <div class="box-body">
        
        

      	<table id="dataTable" class="table table-bordered table-striped" align="center">
          <thead>
            <tr>
              <th width="2%">No.</th>
              <th>Nama Pegawai</th>
              <th></th>
              <th></th>
            </tr>
          </thead>

          <tbody>
            <?php foreach ($pegawai as $p) { ?>
            <tr>
              <td>1</td>
              <td><?= $p->gelarDepan ?> <?= ucwords($p->namaPegawai) ?> <?= $p->gelarBelakang ?></td>
              <td><?= $p->posisiStatus ?></td>
              <td><?= $this->tag->checkField(['pegawai', 'value' => $p->idPegawai, 'id' => 'p' . $p->idPegawai, 'name' => 'pegawai[]']) ?></td>
            </tr>
            <?php } ?>
          </tbody>
          
        </table>

      </div>
      <!-- /.box-body -->

      <div class="box-footer">
        <?= $this->tag->submitButton(['Add', 'id' => 'submit', 'class' => 'btn btn-primary']) ?>
        
        <!-- /.openModal -->
      </div>

    </div>
    <!-- /.box -->
  </div>
  <!-- /.col-md-12 -->
</form>

<script>
// let status = "<?= $this->auth->getIdentity()['profile'] ?>"
// if (status == "Kepegawaian") {
//   $("#openModal").show();
//   $("#submit").hide();
// } else if(status == "Pelayanan") {
//   $("#openModal").hide();
//   $("#submit").show();
// } else {
//   $("#openModal").hide();
//   $("#submit").hide();
// }


$(document).ready(function() {
  let table = $('#dataTable').dataTable();


  $('form').on('submit', function(e){
     var $form = $(this);

     // Iterate over all checkboxes in the table
     table.$('input[type="checkbox"]').each(function(){
        // If checkbox doesn't exist in DOM
        if(!$.contains(document, this)){
           // If checkbox is checked
           if(this.checked){
              // Create a hidden element 
              $form.append(
                 $('<input>')
                    .attr('type', 'hidden')
                    .attr('name', this.name)
                    .val(this.value)
              );
           }
        } 
     });          
  });
});
</script>