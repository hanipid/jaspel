<?php return array (
  0 => 
  array (
    0 => 'idGolongan',
    1 => 'namaGolongan',
    2 => 'pajak',
  ),
  1 => 
  array (
    0 => 'idGolongan',
  ),
  2 => 
  array (
    0 => 'namaGolongan',
    1 => 'pajak',
  ),
  3 => 
  array (
    0 => 'idGolongan',
  ),
  4 => 
  array (
    'idGolongan' => 0,
    'namaGolongan' => 2,
    'pajak' => 0,
  ),
  5 => 
  array (
    'idGolongan' => true,
    'pajak' => true,
  ),
  8 => 'idGolongan',
  9 => 
  array (
    'idGolongan' => 1,
    'namaGolongan' => 2,
    'pajak' => 1,
  ),
  10 => 
  array (
  ),
  11 => 
  array (
  ),
  12 => 
  array (
    'namaGolongan' => NULL,
    'pajak' => NULL,
  ),
  13 => 
  array (
  ),
); 