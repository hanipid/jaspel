<?php return array (
  0 => 
  array (
    0 => 'idJabatan',
    1 => 'namaJabatan',
  ),
  1 => 
  array (
    0 => 'idJabatan',
  ),
  2 => 
  array (
    0 => 'namaJabatan',
  ),
  3 => 
  array (
    0 => 'idJabatan',
  ),
  4 => 
  array (
    'idJabatan' => 0,
    'namaJabatan' => 2,
  ),
  5 => 
  array (
    'idJabatan' => true,
  ),
  8 => 'idJabatan',
  9 => 
  array (
    'idJabatan' => 1,
    'namaJabatan' => 2,
  ),
  10 => 
  array (
  ),
  11 => 
  array (
  ),
  12 => 
  array (
    'namaJabatan' => NULL,
  ),
  13 => 
  array (
  ),
); 