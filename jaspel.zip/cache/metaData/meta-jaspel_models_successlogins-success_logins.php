<?php return array (
  0 => 
  array (
    0 => 'id',
    1 => 'usersId',
    2 => 'ipAddress',
    3 => 'userAgent',
  ),
  1 => 
  array (
    0 => 'id',
  ),
  2 => 
  array (
    0 => 'usersId',
    1 => 'ipAddress',
    2 => 'userAgent',
  ),
  3 => 
  array (
    0 => 'id',
    1 => 'usersId',
    2 => 'ipAddress',
    3 => 'userAgent',
  ),
  4 => 
  array (
    'id' => 0,
    'usersId' => 0,
    'ipAddress' => 5,
    'userAgent' => 2,
  ),
  5 => 
  array (
    'id' => true,
    'usersId' => true,
  ),
  8 => 'id',
  9 => 
  array (
    'id' => 1,
    'usersId' => 1,
    'ipAddress' => 2,
    'userAgent' => 2,
  ),
  10 => 
  array (
  ),
  11 => 
  array (
  ),
  12 => 
  array (
  ),
  13 => 
  array (
  ),
); 