<?php return array (
  0 => 
  array (
    0 => 'id',
    1 => 'usersId',
    2 => 'ipAddress',
    3 => 'attempted',
  ),
  1 => 
  array (
    0 => 'id',
  ),
  2 => 
  array (
    0 => 'usersId',
    1 => 'ipAddress',
    2 => 'attempted',
  ),
  3 => 
  array (
    0 => 'id',
    1 => 'ipAddress',
    2 => 'attempted',
  ),
  4 => 
  array (
    'id' => 0,
    'usersId' => 0,
    'ipAddress' => 5,
    'attempted' => 0,
  ),
  5 => 
  array (
    'id' => true,
    'usersId' => true,
    'attempted' => true,
  ),
  8 => 'id',
  9 => 
  array (
    'id' => 1,
    'usersId' => 1,
    'ipAddress' => 2,
    'attempted' => 1,
  ),
  10 => 
  array (
  ),
  11 => 
  array (
  ),
  12 => 
  array (
    'usersId' => NULL,
  ),
  13 => 
  array (
  ),
); 