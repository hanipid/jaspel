<?php return array (
  0 => 
  array (
    0 => 'id',
    1 => 'usersId',
    2 => 'code',
    3 => 'createdAt',
    4 => 'modifiedAt',
    5 => 'reset',
  ),
  1 => 
  array (
    0 => 'id',
  ),
  2 => 
  array (
    0 => 'usersId',
    1 => 'code',
    2 => 'createdAt',
    3 => 'modifiedAt',
    4 => 'reset',
  ),
  3 => 
  array (
    0 => 'id',
    1 => 'usersId',
    2 => 'code',
    3 => 'createdAt',
    4 => 'reset',
  ),
  4 => 
  array (
    'id' => 0,
    'usersId' => 0,
    'code' => 2,
    'createdAt' => 0,
    'modifiedAt' => 0,
    'reset' => 5,
  ),
  5 => 
  array (
    'id' => true,
    'usersId' => true,
    'createdAt' => true,
    'modifiedAt' => true,
  ),
  8 => 'id',
  9 => 
  array (
    'id' => 1,
    'usersId' => 1,
    'code' => 2,
    'createdAt' => 1,
    'modifiedAt' => 1,
    'reset' => 2,
  ),
  10 => 
  array (
  ),
  11 => 
  array (
  ),
  12 => 
  array (
    'modifiedAt' => NULL,
  ),
  13 => 
  array (
  ),
); 