<?php return array (
  0 => 
  array (
    0 => 'id',
    1 => 'namaPelayanan',
  ),
  1 => 
  array (
    0 => 'id',
  ),
  2 => 
  array (
    0 => 'namaPelayanan',
  ),
  3 => 
  array (
    0 => 'id',
  ),
  4 => 
  array (
    'id' => 0,
    'namaPelayanan' => 2,
  ),
  5 => 
  array (
    'id' => true,
  ),
  8 => 'id',
  9 => 
  array (
    'id' => 1,
    'namaPelayanan' => 2,
  ),
  10 => 
  array (
  ),
  11 => 
  array (
  ),
  12 => 
  array (
    'namaPelayanan' => NULL,
  ),
  13 => 
  array (
  ),
); 