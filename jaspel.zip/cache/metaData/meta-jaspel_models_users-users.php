<?php return array (
  0 => 
  array (
    0 => 'id',
    1 => 'idPegawai',
    2 => 'idRuangan',
    3 => 'name',
    4 => 'email',
    5 => 'password',
    6 => 'mustChangePassword',
    7 => 'profilesId',
    8 => 'banned',
    9 => 'suspended',
    10 => 'active',
  ),
  1 => 
  array (
    0 => 'id',
  ),
  2 => 
  array (
    0 => 'idPegawai',
    1 => 'idRuangan',
    2 => 'name',
    3 => 'email',
    4 => 'password',
    5 => 'mustChangePassword',
    6 => 'profilesId',
    7 => 'banned',
    8 => 'suspended',
    9 => 'active',
  ),
  3 => 
  array (
    0 => 'id',
    1 => 'name',
    2 => 'email',
    3 => 'password',
    4 => 'profilesId',
    5 => 'banned',
    6 => 'suspended',
  ),
  4 => 
  array (
    'id' => 0,
    'idPegawai' => 0,
    'idRuangan' => 0,
    'name' => 2,
    'email' => 2,
    'password' => 5,
    'mustChangePassword' => 5,
    'profilesId' => 0,
    'banned' => 5,
    'suspended' => 5,
    'active' => 5,
  ),
  5 => 
  array (
    'id' => true,
    'idPegawai' => true,
    'idRuangan' => true,
    'profilesId' => true,
  ),
  8 => 'id',
  9 => 
  array (
    'id' => 1,
    'idPegawai' => 1,
    'idRuangan' => 1,
    'name' => 2,
    'email' => 2,
    'password' => 2,
    'mustChangePassword' => 2,
    'profilesId' => 1,
    'banned' => 2,
    'suspended' => 2,
    'active' => 2,
  ),
  10 => 
  array (
  ),
  11 => 
  array (
  ),
  12 => 
  array (
    'idPegawai' => NULL,
    'idRuangan' => NULL,
    'mustChangePassword' => NULL,
    'active' => NULL,
  ),
  13 => 
  array (
  ),
); 