<?php return array (
  0 => 
  array (
    0 => 'id',
    1 => 'nama',
    2 => 'deskripsi',
    3 => 'controller',
    4 => 'url',
    5 => 'parent',
    6 => 'sort',
  ),
  1 => 
  array (
    0 => 'id',
  ),
  2 => 
  array (
    0 => 'nama',
    1 => 'deskripsi',
    2 => 'controller',
    3 => 'url',
    4 => 'parent',
    5 => 'sort',
  ),
  3 => 
  array (
    0 => 'id',
    1 => 'nama',
    2 => 'parent',
  ),
  4 => 
  array (
    'id' => 0,
    'nama' => 2,
    'deskripsi' => 2,
    'controller' => 2,
    'url' => 2,
    'parent' => 0,
    'sort' => 0,
  ),
  5 => 
  array (
    'id' => true,
    'parent' => true,
    'sort' => true,
  ),
  8 => 'id',
  9 => 
  array (
    'id' => 1,
    'nama' => 2,
    'deskripsi' => 2,
    'controller' => 2,
    'url' => 2,
    'parent' => 1,
    'sort' => 1,
  ),
  10 => 
  array (
  ),
  11 => 
  array (
  ),
  12 => 
  array (
    'deskripsi' => NULL,
    'controller' => NULL,
    'url' => NULL,
    'sort' => NULL,
  ),
  13 => 
  array (
  ),
); 