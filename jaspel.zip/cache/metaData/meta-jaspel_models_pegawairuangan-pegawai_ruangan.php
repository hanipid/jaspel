<?php return array (
  0 => 
  array (
    0 => 'id',
    1 => 'idPegawai',
    2 => 'idRuangan',
    3 => 'tglAktifitas',
    4 => 'statusInOut',
    5 => 'statusPosisi',
    6 => 'statusAktif',
    7 => 'sort',
  ),
  1 => 
  array (
    0 => 'id',
  ),
  2 => 
  array (
    0 => 'idPegawai',
    1 => 'idRuangan',
    2 => 'tglAktifitas',
    3 => 'statusInOut',
    4 => 'statusPosisi',
    5 => 'statusAktif',
    6 => 'sort',
  ),
  3 => 
  array (
    0 => 'id',
  ),
  4 => 
  array (
    'id' => 0,
    'idPegawai' => 0,
    'idRuangan' => 0,
    'tglAktifitas' => 1,
    'statusInOut' => 2,
    'statusPosisi' => 2,
    'statusAktif' => 2,
    'sort' => 2,
  ),
  5 => 
  array (
    'id' => true,
    'idPegawai' => true,
    'idRuangan' => true,
  ),
  8 => 'id',
  9 => 
  array (
    'id' => 1,
    'idPegawai' => 1,
    'idRuangan' => 1,
    'tglAktifitas' => 2,
    'statusInOut' => 2,
    'statusPosisi' => 2,
    'statusAktif' => 2,
    'sort' => 2,
  ),
  10 => 
  array (
  ),
  11 => 
  array (
  ),
  12 => 
  array (
    'idPegawai' => NULL,
    'idRuangan' => NULL,
    'tglAktifitas' => NULL,
    'statusInOut' => NULL,
    'statusPosisi' => NULL,
    'statusAktif' => NULL,
    'sort' => NULL,
  ),
  13 => 
  array (
  ),
); 