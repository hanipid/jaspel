<?php return array (
  0 => 
  array (
    0 => 'id',
    1 => 'idRuangan',
    2 => 'idJenisPelayanan',
    3 => 'persentaseSarana',
    4 => 'persentasePelayanan',
    5 => 'persentaseDokter',
    6 => 'persentasePerawat',
    7 => 'kategori',
    8 => 'metode',
    9 => 'statusAktif',
  ),
  1 => 
  array (
    0 => 'id',
  ),
  2 => 
  array (
    0 => 'idRuangan',
    1 => 'idJenisPelayanan',
    2 => 'persentaseSarana',
    3 => 'persentasePelayanan',
    4 => 'persentaseDokter',
    5 => 'persentasePerawat',
    6 => 'kategori',
    7 => 'metode',
    8 => 'statusAktif',
  ),
  3 => 
  array (
    0 => 'id',
    1 => 'idRuangan',
    2 => 'idJenisPelayanan',
  ),
  4 => 
  array (
    'id' => 0,
    'idRuangan' => 0,
    'idJenisPelayanan' => 0,
    'persentaseSarana' => 9,
    'persentasePelayanan' => 9,
    'persentaseDokter' => 9,
    'persentasePerawat' => 9,
    'kategori' => 2,
    'metode' => 2,
    'statusAktif' => 2,
  ),
  5 => 
  array (
    'id' => true,
    'idRuangan' => true,
    'idJenisPelayanan' => true,
    'persentaseSarana' => true,
    'persentasePelayanan' => true,
    'persentaseDokter' => true,
    'persentasePerawat' => true,
  ),
  8 => 'id',
  9 => 
  array (
    'id' => 1,
    'idRuangan' => 1,
    'idJenisPelayanan' => 1,
    'persentaseSarana' => 32,
    'persentasePelayanan' => 32,
    'persentaseDokter' => 32,
    'persentasePerawat' => 32,
    'kategori' => 2,
    'metode' => 2,
    'statusAktif' => 2,
  ),
  10 => 
  array (
  ),
  11 => 
  array (
  ),
  12 => 
  array (
    'persentaseSarana' => NULL,
    'persentasePelayanan' => NULL,
    'persentaseDokter' => NULL,
    'persentasePerawat' => NULL,
    'kategori' => NULL,
    'metode' => NULL,
    'statusAktif' => NULL,
  ),
  13 => 
  array (
  ),
); 