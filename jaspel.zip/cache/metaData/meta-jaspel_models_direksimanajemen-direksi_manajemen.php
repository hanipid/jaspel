<?php return array (
  0 => 
  array (
    0 => 'id',
    1 => 'idPegawai',
    2 => 'tglAktifitas',
    3 => 'nilaiPersentase',
    4 => 'statusInOut',
    5 => 'statusPosisi',
    6 => 'statusAktif',
    7 => 'sort',
  ),
  1 => 
  array (
    0 => 'id',
  ),
  2 => 
  array (
    0 => 'idPegawai',
    1 => 'tglAktifitas',
    2 => 'nilaiPersentase',
    3 => 'statusInOut',
    4 => 'statusPosisi',
    5 => 'statusAktif',
    6 => 'sort',
  ),
  3 => 
  array (
    0 => 'id',
  ),
  4 => 
  array (
    'id' => 0,
    'idPegawai' => 0,
    'tglAktifitas' => 1,
    'nilaiPersentase' => 9,
    'statusInOut' => 2,
    'statusPosisi' => 2,
    'statusAktif' => 0,
    'sort' => 2,
  ),
  5 => 
  array (
    'id' => true,
    'idPegawai' => true,
    'nilaiPersentase' => true,
    'statusAktif' => true,
  ),
  8 => 'id',
  9 => 
  array (
    'id' => 1,
    'idPegawai' => 1,
    'tglAktifitas' => 2,
    'nilaiPersentase' => 32,
    'statusInOut' => 2,
    'statusPosisi' => 2,
    'statusAktif' => 1,
    'sort' => 2,
  ),
  10 => 
  array (
  ),
  11 => 
  array (
  ),
  12 => 
  array (
    'idPegawai' => NULL,
    'tglAktifitas' => NULL,
    'nilaiPersentase' => NULL,
    'statusInOut' => NULL,
    'statusPosisi' => NULL,
    'statusAktif' => NULL,
    'sort' => NULL,
  ),
  13 => 
  array (
  ),
); 