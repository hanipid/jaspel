<?php return array (
  0 => 
  array (
    0 => 'id',
    1 => 'namaRuang',
    2 => 'jenisRuang',
    3 => 'statusAktif',
  ),
  1 => 
  array (
    0 => 'id',
  ),
  2 => 
  array (
    0 => 'namaRuang',
    1 => 'jenisRuang',
    2 => 'statusAktif',
  ),
  3 => 
  array (
    0 => 'id',
  ),
  4 => 
  array (
    'id' => 0,
    'namaRuang' => 2,
    'jenisRuang' => 2,
    'statusAktif' => 2,
  ),
  5 => 
  array (
    'id' => true,
  ),
  8 => 'id',
  9 => 
  array (
    'id' => 1,
    'namaRuang' => 2,
    'jenisRuang' => 2,
    'statusAktif' => 2,
  ),
  10 => 
  array (
  ),
  11 => 
  array (
  ),
  12 => 
  array (
    'namaRuang' => NULL,
    'jenisRuang' => NULL,
    'statusAktif' => NULL,
  ),
  13 => 
  array (
  ),
); 