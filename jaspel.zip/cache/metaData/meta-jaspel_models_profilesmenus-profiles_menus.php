<?php return array (
  0 => 
  array (
    0 => 'profilesId',
    1 => 'menusId',
  ),
  1 => 
  array (
  ),
  2 => 
  array (
    0 => 'profilesId',
    1 => 'menusId',
  ),
  3 => 
  array (
    0 => 'profilesId',
    1 => 'menusId',
  ),
  4 => 
  array (
    'profilesId' => 0,
    'menusId' => 0,
  ),
  5 => 
  array (
    'profilesId' => true,
    'menusId' => true,
  ),
  8 => false,
  9 => 
  array (
    'profilesId' => 1,
    'menusId' => 1,
  ),
  10 => 
  array (
  ),
  11 => 
  array (
  ),
  12 => 
  array (
  ),
  13 => 
  array (
  ),
); 