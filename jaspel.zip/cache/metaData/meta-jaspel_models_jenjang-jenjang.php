<?php return array (
  0 => 
  array (
    0 => 'idJenjang',
    1 => 'namaJenjang',
  ),
  1 => 
  array (
    0 => 'idJenjang',
  ),
  2 => 
  array (
    0 => 'namaJenjang',
  ),
  3 => 
  array (
    0 => 'idJenjang',
  ),
  4 => 
  array (
    'idJenjang' => 0,
    'namaJenjang' => 2,
  ),
  5 => 
  array (
    'idJenjang' => true,
  ),
  8 => 'idJenjang',
  9 => 
  array (
    'idJenjang' => 1,
    'namaJenjang' => 2,
  ),
  10 => 
  array (
  ),
  11 => 
  array (
  ),
  12 => 
  array (
    'namaJenjang' => NULL,
  ),
  13 => 
  array (
  ),
); 