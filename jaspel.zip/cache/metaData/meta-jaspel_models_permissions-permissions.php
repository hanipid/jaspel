<?php return array (
  0 => 
  array (
    0 => 'id',
    1 => 'profilesId',
    2 => 'resource',
    3 => 'action',
  ),
  1 => 
  array (
    0 => 'id',
  ),
  2 => 
  array (
    0 => 'profilesId',
    1 => 'resource',
    2 => 'action',
  ),
  3 => 
  array (
    0 => 'id',
    1 => 'profilesId',
    2 => 'resource',
    3 => 'action',
  ),
  4 => 
  array (
    'id' => 0,
    'profilesId' => 0,
    'resource' => 2,
    'action' => 2,
  ),
  5 => 
  array (
    'id' => true,
    'profilesId' => true,
  ),
  8 => 'id',
  9 => 
  array (
    'id' => 1,
    'profilesId' => 1,
    'resource' => 2,
    'action' => 2,
  ),
  10 => 
  array (
  ),
  11 => 
  array (
  ),
  12 => 
  array (
  ),
  13 => 
  array (
  ),
); 