<?php return array (
  0 => 
  array (
    0 => 'idPangkat',
    1 => 'namaPangkat',
  ),
  1 => 
  array (
    0 => 'idPangkat',
  ),
  2 => 
  array (
    0 => 'namaPangkat',
  ),
  3 => 
  array (
    0 => 'idPangkat',
  ),
  4 => 
  array (
    'idPangkat' => 0,
    'namaPangkat' => 2,
  ),
  5 => 
  array (
    'idPangkat' => true,
  ),
  8 => 'idPangkat',
  9 => 
  array (
    'idPangkat' => 1,
    'namaPangkat' => 2,
  ),
  10 => 
  array (
  ),
  11 => 
  array (
  ),
  12 => 
  array (
    'namaPangkat' => NULL,
  ),
  13 => 
  array (
  ),
); 