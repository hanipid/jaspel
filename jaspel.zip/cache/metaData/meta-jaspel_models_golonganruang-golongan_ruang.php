<?php return array (
  0 => 
  array (
    0 => 'idGolonganRuang',
    1 => 'namaGolonganRuang',
  ),
  1 => 
  array (
    0 => 'idGolonganRuang',
  ),
  2 => 
  array (
    0 => 'namaGolonganRuang',
  ),
  3 => 
  array (
    0 => 'idGolonganRuang',
  ),
  4 => 
  array (
    'idGolonganRuang' => 0,
    'namaGolonganRuang' => 2,
  ),
  5 => 
  array (
    'idGolonganRuang' => true,
  ),
  8 => 'idGolonganRuang',
  9 => 
  array (
    'idGolonganRuang' => 1,
    'namaGolonganRuang' => 2,
  ),
  10 => 
  array (
  ),
  11 => 
  array (
  ),
  12 => 
  array (
    'namaGolonganRuang' => NULL,
  ),
  13 => 
  array (
  ),
); 