<?php return array (
  0 => 
  array (
    0 => 'idPJaspel',
    1 => 'direksi',
    2 => 'jasa',
    3 => 'jpu',
    4 => 'jpl',
    5 => 'admin',
    6 => 'jasaFix',
  ),
  1 => 
  array (
    0 => 'idPJaspel',
  ),
  2 => 
  array (
    0 => 'direksi',
    1 => 'jasa',
    2 => 'jpu',
    3 => 'jpl',
    4 => 'admin',
    5 => 'jasaFix',
  ),
  3 => 
  array (
    0 => 'idPJaspel',
  ),
  4 => 
  array (
    'idPJaspel' => 0,
    'direksi' => 9,
    'jasa' => 9,
    'jpu' => 9,
    'jpl' => 9,
    'admin' => 9,
    'jasaFix' => 9,
  ),
  5 => 
  array (
    'idPJaspel' => true,
    'direksi' => true,
    'jasa' => true,
    'jpu' => true,
    'jpl' => true,
    'admin' => true,
    'jasaFix' => true,
  ),
  8 => 'idPJaspel',
  9 => 
  array (
    'idPJaspel' => 1,
    'direksi' => 32,
    'jasa' => 32,
    'jpu' => 32,
    'jpl' => 32,
    'admin' => 32,
    'jasaFix' => 32,
  ),
  10 => 
  array (
  ),
  11 => 
  array (
  ),
  12 => 
  array (
    'direksi' => NULL,
    'jasa' => NULL,
    'jpu' => NULL,
    'jpl' => NULL,
    'admin' => NULL,
    'jasaFix' => NULL,
  ),
  13 => 
  array (
  ),
); 