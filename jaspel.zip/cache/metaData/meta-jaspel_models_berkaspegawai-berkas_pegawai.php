<?php return array (
  0 => 
  array (
    0 => 'idBerkasPegawai',
    1 => 'namaFile',
    2 => 'idPegawai',
  ),
  1 => 
  array (
    0 => 'idBerkasPegawai',
  ),
  2 => 
  array (
    0 => 'namaFile',
    1 => 'idPegawai',
  ),
  3 => 
  array (
    0 => 'idBerkasPegawai',
    1 => 'namaFile',
    2 => 'idPegawai',
  ),
  4 => 
  array (
    'idBerkasPegawai' => 0,
    'namaFile' => 2,
    'idPegawai' => 0,
  ),
  5 => 
  array (
    'idBerkasPegawai' => true,
    'idPegawai' => true,
  ),
  8 => 'idBerkasPegawai',
  9 => 
  array (
    'idBerkasPegawai' => 1,
    'namaFile' => 2,
    'idPegawai' => 1,
  ),
  10 => 
  array (
  ),
  11 => 
  array (
  ),
  12 => 
  array (
  ),
  13 => 
  array (
  ),
); 